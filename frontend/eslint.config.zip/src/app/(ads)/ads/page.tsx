'use client'

import { useEffect, useState, useMemo } from 'react'
import { useAppDispatch, useAppSelector } from '@/store/store'
import { fetchAds } from '@/store/slices/ads/adsAction'
import ListingFilters from '@/components/ListingsFilters'
import ListingGrid from '@/components/ListingGrid'
import { Skeleton } from '@/components/ui/skeleton'
import { Button } from '@/components/ui/button'
import type { Ads } from '@/types/IAds'

export default function ListingsPage() {
  const dispatch = useAppDispatch()
  const { items: ads, count, loading, error } = useAppSelector(s => s.ads)

  const [currentPage, setCurrentPage] = useState(1)
  const [filteredAds, setFilteredAds] = useState<Ads[]>([])

  useEffect(() => {
    dispatch(fetchAds({ page: currentPage }))
  }, [dispatch, currentPage])

  useEffect(() => {
    setFilteredAds(ads)
  }, [ads])

  const handleFilter = (adsList: Ads[]) => {
    setFilteredAds(adsList)
    setCurrentPage(1)
  }

  const sortedAds = useMemo(() => {
    return [...filteredAds].sort((a, b) =>
      b.is_featured === a.is_featured ? 0 : b.is_featured ? 1 : -1
    )
  }, [filteredAds])

  const PAGE_SIZE = 8
  const totalPages = Math.ceil(count / PAGE_SIZE)

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-3xl font-bold mb-6">Все объявления</h1>
      <div className="grid grid-cols-1 md:grid-cols-[300px_1fr] gap-6">
        <aside>
          <ListingFilters onFilter={handleFilter} />
        </aside>
        <div>
          {error && <p className="text-red-600 mb-4">Ошибка: {error}</p>}

          {loading ? (
            <Skeleton />
          ) : sortedAds.length > 0 ? (
            <ListingGrid listings={sortedAds} />
          ) : (
            <p className="text-center py-10">Нет объявлений</p>
          )}

          {totalPages > 1 && (
            <div className="flex space-x-2 justify-center mt-6">
              {[...Array(totalPages)].map((_, i) => {
                const p = i + 1
                function loadPage(p: number): void {
                  setCurrentPage(p)
                }

                return (
                  <Button
                    key={p}
                    variant={p === currentPage ? 'default' : 'outline'}
                    onClick={() => loadPage(p)}
                  >
                    {p}
                  </Button>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
