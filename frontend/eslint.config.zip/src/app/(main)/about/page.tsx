export default function AboutPage() {
    return (
      <main className="p-6">
        <h1 className="text-2xl font-bold">О проекте DIaẋedarş</h1>
        <p>Сервис объявлений для вайнахов в Европе.</p>
      </main>
    )
  }
  