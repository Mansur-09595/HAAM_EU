export default function FavoritesPage() {
    return (
      <main className="p-6">
        <h1 className="text-2xl font-bold">Избранное</h1>
        <p>Здесь будут ваши избранные объявления.</p>
      </main>
    )
  }
  